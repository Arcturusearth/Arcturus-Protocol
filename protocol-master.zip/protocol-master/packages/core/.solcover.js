module.exports = require("@umaprotocol/common").SolcoverConfig;
