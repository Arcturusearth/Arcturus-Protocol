module.exports = require("@umaprotocol/common").getTruffleConfig(__dirname);
