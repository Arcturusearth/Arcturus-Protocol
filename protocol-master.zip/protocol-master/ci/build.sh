#!/usr/bin/env bash
set -e

yarn run truffle compile
