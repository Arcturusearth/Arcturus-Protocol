// Note: this config is only here as a matter of convenience to allow all truffle commands that can be run from core work at root as well.
module.exports = require("@umaprotocol/common").getTruffleConfig("./packages/core");
